

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Create")
public class Create extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Update Employee</h1>");
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		
		Emp e=EmpDao.getEmployeeById(id);
		
		out.print("<form action='Read' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");
		out.print("<tr><td>FirstName:</td><td><input type='text' name='FirstName' value='"+e.getFirstName()+"'/></td></tr>");
		out.print("<tr><td>Employee Id</td><td><input type='hidden' name='id' value='"+e.getEmployeeId()+"'/></td></tr>");
		out.print("<tr><td>LastName:</td><td><input type='test' name='LastName' value='"+e.getLastName()+"'/></td></tr>");
		out.print("<tr><td>Start Date:</td><td><input type='Date' name='StartDate' value='"+e.getStart Date()+"'/></td></tr>");
		out.print("<tr>td>End Date:</td><td><input type='Date' name='End Date' value='"+e.getEnd Date()+"'/></td></tr>");
		out.print("<tr><td>Designation:</td><td><input type='text' name='Designation' value='"+e.getDesignation()+"'/></td></tr>");
		out.print("<tr><td>Department:</td><td><input type='text' name='Department' value='"+e.getDepartment()+"'/></td></tr>");
		out.print("<tr><td>Date of Birth:</td><td><input type='Date' name='Date of Birth:' value='"+e.getDate of Birth:()+"'/></td></tr>");
		out.print("<tr><td>Reporting manger:</td><td><input type='text' name='Reporting manger' value='"+e.getReporting manger()+"'/></td></tr>");
		out.print("<tr><td>Gender:</td><td>");
		out.print("<select name='Gender' style='width:150px'>");
		out.print("<option>Male</option>");
		out.print("<option>Female</option>");
		out.print("<option>Other</option>");
		out.print("</select>");
		out.print("</td></tr>");
		out.print("<tr><td>Blood Group:</td><td><input type='text' name='Blood Group' value='"+e.getBlood Group()+"'/></td></tr>");
		out.print("<tr><td>Address:</td><td><input type='text' name='Address' value='"+e.getAddress()+"'/></td></tr>");
		out.print("<tr><td>Dependent:</td><td>");
		out.print("<td>FirstName:</td><td><input type='text' name='FirstName' value='"+e.getFirstName()+"'/></td>");
		out.print("<td>LastName:</td><td><input type='test' name='LastName' value='"+e.getLastName()+"'/></td>");
		out.print("<td>Date of Birth:</td><td><input type='Date' name='Date of Birth:' value='"+e.getDate of Birth:()+"'/></td>");
		out.print("<td>Gender:</td><td>");
		out.print("<select name='Gender' style='width:150px'>");
		out.print("<option>Male</option>");
		out.print("<option>Female</option>");
		out.print("<option>Other</option>");
		out.print("</select>");
		out.print("<td>Relationship:</td><td>");
		out.print("<select name='Relationship' style='width:150px'>");
		out.print("<option>Father</option>");
		out.print("<option>Mother</option>");
		out.print("<option>Wife</option>");
		out.print("<option>Other</option>");
		out.print("</select></tr>");
		out.print("<tr><td>Education Qualification:</td><td><input type='text' name='Education Qualification' value='"+e.getEducation Qualification()+"'/></td>");
        out.print("<td>Type:</td><td>");
		out.print("<select name='Type' style='width:150px'>");
		out.print("<option>Engineer</option>");
		out.print("<option>Degree</option>");
		out.print("<option>Diploma</option>");
		out.print("<option>Other</option>");
		out.print("</select>");
        out.print("<td>Start Date:</td><td><input type='Date' name='StartDate' value='"+e.getStart Date()+"'/></td>");
		out.print("<td>End Date:</td><td><input type='Date' name='End Date' value='"+e.getEnd Date()+"'/></td>");
        out.print("<td>Address:</td><td><input type='text' name='Address' value='"+e.getAddress()+"'/></td>");
        out.print("<td>Percentage:</td><td><input type='text' name='Percentage' value='"+e.getPercentage()+"'/></td>");
        out.print("<td>collage/Institution</td><td><input type='text' name='collage/Institution' value='"+e.getcollage/Institution()+"'/></td></tr>");
        out.print("<tr><td colspan='2'><input type='submit' value='Edit &amp; Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");
		
		out.close();
	}
}
