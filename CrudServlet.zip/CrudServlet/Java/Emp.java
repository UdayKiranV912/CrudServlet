
public class Emp
{
private int id,employee ID ;
private String fastName,LastName,employee ID,Start Date,End Date,Designation,Department,Date Of Birth,Reporting manger,Gender,Address,Dependent,Education QualificationCollage/Institution,Percentage;
public void setId(int id,employee ID)
 {
	this.id = id
	this.employee ID=employee ID;
  }
public String getname(fastName,LastName,employee ID,Start Date,End Date,Designation,Department,Date Of Birth,Reporting manger,Gender,Address)
{
	return name;
}
public void setname(String fastName,LastName,Start Date,End Date,Designation,Department,Reporting manger,Gender,Address)
{
	this.FirstName = FirstName;
	this.LastName = LastName;
	this.Start Date=Start Date;
	this.End Date=End Date;
	this.Designation=Designation;
	this.Department=Department;
	this.Reporting manger=Reporting manger;
	this.Gender=Gender;
    this.Address=Address;
}
public String getCDependent(String Dependent,FirstName,LastName,Gender,Date of Birth,Relationship)
 {
	return Dependent;
}
public void setDependent(String Dependent,FirstName,LastName,Gender,Date of Birth,Relationship)
{
	this.Dependent = Dependent;
	this.FirstName = FirstName;
	this.LastName = LastName;
	this.Date of Birth = Date of Birth;
	this.Relationship = Relationship;

}
public String getEducation Qualification(String Education Qualification,Type,Start Date,End Date,Collage/Institution,Address,Percentage)
 {
	return Education Qualification;
}
public void setEducation Qualification(String Education Qualification,Type,Start Date,End Date,Collage/Institution,Address,Percentage)
{
	this.Education Qualification =Education Qualification;
	this.Type=Type;
	this.Start Date=Start Date;
	this.End Date=End Date;
	this.Collage/Institution=collage/Institution;
	this.Address=Address;
	this.percentage=percentage;
}
}
