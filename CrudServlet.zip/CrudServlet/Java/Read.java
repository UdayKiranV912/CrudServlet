

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Read")
public class read servlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String FirstName=request.getParameter("FirstName");
		String LastName=request.getParameter("LastName");
		String Start Date=request.getParameter("Start Date");
		String End Date=request.getParameter("End Date");
		String Designation=request.getParameter("Designation");
		String Department=request.getParameter("Department");
		String Date of Birth=request.getParameter("Date of Birth")
		String Gender=request.getParameter("Gender");
		String Blood Group=request.getParameter("Blood Group");
        String Address=request.getParameter("Address");
		String Dependent=request.getParameter("Dependent");
		String FirstName=request.getParameter("FirstName");
		String LastName=request.getParameter("LastName");
        String Date of Birth=request.getParameter("Date of Birth")
        String Gender=request.getParameter("Gender");
        String Dependent=request.getParameter("Dependent");
		String Education Qualification=request.getParameter("Education Qualification");
        String Start Date=request.getParameter("Start Date");
        String End Date=request.getParameter("End Date");
		String Type=request.getParameter("Type");
		String Collage/Institution=request.getParameter("Collage/Institution");
        String Address=request.getParameter("Address")
        String percentage=request.getParameter("percentage");
		Emp e=new Emp();
		e.setId(id,Employee Id);
		e.setName(fastName,LastName,employee ID,Start Date,End Date,Designation,Department,Date Of Birth,Reporting manger,Gender,Address);
		e.setDependent(Dependent,FirstName,LastName,Gender,Date of Birth,Relationship);
		e.setEducation Qualification(Qualification,Type,Start Date,End Date,Collage/Institution,Address,Percentage);
		
		int status=EmpDao.update(e);
		if(status>0)
		{
			response.sendRedirect("Save employee");
		}
		else
		{
			out.println("Sorry! unable to update record");
		}
		
		out.close();
	}

}
